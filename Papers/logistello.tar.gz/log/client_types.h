// (c) Michael Buro 1992-2002, licensed under the GNU Public License, version 2

typedef sint1   signed char
typedef sint2   signed short
typedef sint4   signed long
typedef sint8   signed long long

typedef uint1   unsigned char
typedef uint2   unsigned short
typedef uint4   unsigned long
typedef uint8   unsigned long long

