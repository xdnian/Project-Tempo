// (c) Michael Buro 1992-2002, licensed under the GNU Public License, version 2

#include "main.h"

uint1 Set8B[6561*8+1] = {
#include "set8b.inc"
0
};
uint1 Set8W[6561*8+1] = {
#include "set8w.inc"
0
};
uint1 Set7B[2187*8+1] = {
#include "set7b.inc"
0
};
uint1 Set7W[2187*8+1] = {
#include "set7w.inc"
0
};
uint1 Set6B[729*8+1] = {
#include "set6b.inc"
0
};
uint1 Set6W[729*8+1] = {
#include "set6w.inc"
0
};
uint1 Set5B[243*8+1] = {
#include "set5b.inc"
0
};
uint1 Set5W[243*8+1] = {
#include "set5w.inc"
0
};
uint1 Set4B[81*8+1] = {
#include "set4b.inc"
0
};
uint1 Set4W[81*8+1] = {
#include "set4w.inc"
0
};
uint1 Set3B[27*8+1] = {
#include "set3b.inc"
0
};
uint1 Set3W[27*8+1] = {
#include "set3w.inc"
0
};
