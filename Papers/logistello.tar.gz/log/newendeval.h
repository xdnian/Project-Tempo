// (c) Michael Buro 1992-2002, licensed under the GNU Public License, version 2

#ifndef NEWENDEVAL_H
#define NEWENDEVAL_H

#include "eval.h"

WERT NewEndEval(BRETT *pb, PARTEI player);

extern MERKMAL_B NEWENDEVAL_B;
extern MERKMAL NEWENDEVAL;

#endif
