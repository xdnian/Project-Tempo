// (c) Michael Buro 1992-2002, licensed under the GNU Public License, version 2

/* BS-Funktionen f�r Amiga */

#ifndef AMIGA_H
#define AMIGA_H

#include "main.h"

#include <functions.h>
#include <intuition/gadgetclass.h>

#endif
