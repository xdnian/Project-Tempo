// (c) Michael Buro 1992-2002, licensed under the GNU Public License, version 2

void	othello_INIT(void);
void	othello_ARGS(char *arg);
void    othello_MATCH(void);
void    othello_CREATE(void);
void    othello_MOVES(void);
void    othello_BOARD(void);
void    othello_ABORT(void);
void    othello_END(void);
void	othello_NORMAL(void);
