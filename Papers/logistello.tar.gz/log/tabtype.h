// (c) Michael Buro 1992-2002, licensed under the GNU Public License, version 2

#ifndef TABTYPE_H
#define TABTYPE_H

#include "main.h"

#ifdef ALPHA
typedef int   TTYPE;
#else
typedef short TTYPE;
#endif

#endif

