// (c) Michael Buro 1992-2002, licensed under the GNU Public License, version 2

#ifndef WEIGHT_H
#define WEIGHT_H

extern int Weight(int val);

#endif
