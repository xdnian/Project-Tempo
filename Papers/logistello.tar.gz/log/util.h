// (c) Michael Buro 1992-2002, licensed under the GNU Public License, version 2

extern float utility(float a, float b, float s, float sigma);

